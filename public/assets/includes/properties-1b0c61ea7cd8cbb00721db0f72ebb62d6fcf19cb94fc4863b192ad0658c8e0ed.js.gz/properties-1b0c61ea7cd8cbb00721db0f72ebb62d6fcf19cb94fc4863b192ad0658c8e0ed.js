// $(function(){
// 	$("#toggleDetails").on("click", function(){
// 		var details = $("#prop-details");

// 		details.toggleclass("open");	
	
// 	})
// });
